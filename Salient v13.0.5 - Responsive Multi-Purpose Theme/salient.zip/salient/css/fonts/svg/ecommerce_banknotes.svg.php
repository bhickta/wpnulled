<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<rect x="1" y="24" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="52" height="26"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="11,22 11,14 63,14 63,40 55,40 "/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M10,46c0-3-2-4-5-4V32c3,0,5-1,5-4h35c0,3,2,4,4,4
	v10c-2,0-4,1-4,4H10z"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="27" cy="37" r="5"/>
</svg>
