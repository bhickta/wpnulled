<a class="btn btn-success waves-effect waves-light" href="{{ url('dashboard/add-new-post')  }}">
    <i class="ti-plus mr-1"></i>
    {{ __('Create New') }}
</a>